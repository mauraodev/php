<?php
	//echo 'Aqui';
	//echo fopen("file://192.168.0.100/servidor/temp/teste.mp3",'r');
?>
<a href="file://192.168.0.100/servidor/temp/teste.mp3">Baixar</a>
<a href="file://192.168.0.100/servidor/temp/2013-11-29_110129.png">Baixar</a>