<?php
echo ":: Descompactando arquivos";

echo ":: Atualizando produto";

echo ":: Atualizando banco de dados";

echo ":: Finalizando atualização";

?>